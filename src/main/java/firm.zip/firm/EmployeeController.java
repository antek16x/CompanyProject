package firm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class EmployeeController {
    @Autowired
    private EmployeeRepository rep;

    @RequestMapping("/firm")
    @ResponseBody
    public List<Employee> getAll() {
        return rep.findAll();
    }

    //DWA SPOSOBY NA PODWYŻKĘ

    @RequestMapping("/firm/{id}/increase/{raise}") // tu podwyzka podawana w url
    @ResponseBody
    public void salaryRaise(@PathVariable("id") Long id, @PathVariable("raise") long raise) {
        rep.salaryRaise(id, raise);
    }

    @RequestMapping("/firm/{id}/increase") // tu podwyzka podawana w body (np. w json)
    @ResponseBody
    public void salaryRaise2(@PathVariable("id") Long id, @RequestBody Salary salaryRaise) {
        Employee employee = rep.getOne(id);
        if (employee != null) {
            employee.setSalary(employee.getSalary().add(salaryRaise));
            rep.save(employee);
        }
    }

    @RequestMapping("firm/{id}")
    @ResponseBody
    public Employee getOne(@PathVariable("id") Long id) {
        return rep.findById(id).orElse(null);
    }

    @RequestMapping("firm/salary/{salaryGr}")
    @ResponseBody
    public List<Employee> getBySalaryGr(@PathVariable("salaryGr") Long salaryGr) {
        return rep.findBySalaryGr(salaryGr);
    }

    @RequestMapping("firm/salaryGreaterThan/{salaryGr}")
    @ResponseBody
    public List<Employee> getSalaryGreaterThan(@PathVariable("salaryGr") Long salaryGr) {
        return rep.findBySalaryGrGreaterThan(salaryGr);
    }

    @RequestMapping("firm/lastName/{name}")
    @ResponseBody
    public List<Employee> getByLastName(@PathVariable("name") String lastName) {
        return rep.findByLastName(lastName);
    }

    @RequestMapping("firm/byLastName")
    @ResponseBody
    public List<Employee> getAllOrderByLastName() {
        return rep.findByOrderByLastName();
    }

    @RequestMapping("firm/size")
    @ResponseBody
    public long size() {
        return rep.count();
    }

    @RequestMapping(value = "/firm", method = RequestMethod.POST)
    @ResponseBody
    public Employee create(@RequestBody Employee employee) {
        employee.setId(null);
        return rep.save(employee);
    }

    @RequestMapping(value = "/firm/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public Employee updateOrCreatePut(@PathVariable("id") Long id, @RequestBody Employee employee) {
        employee.setId(id);
        return rep.save(employee);
    }

    @RequestMapping(value = "/firm/{id}", method = RequestMethod.PATCH)
    @ResponseBody
    public Employee updateOrCreatePatch(@PathVariable("id") Long id, @RequestBody Employee employee) {
        Employee old = rep.getOne(id);
        if (old == null) {
            return rep.save(employee);
        }
        if (employee.getSalary() != null) old.setSalary(employee.getSalary());
        if (employee.getLastName() != null) old.setLastName(employee.getLastName());
        if (employee.getFirstName() != null) old.setFirstName((employee.getFirstName()));
        return rep.save(old);
    }

    @RequestMapping(value = "/firm/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public void delete(@PathVariable("id") Long id) {
        rep.deleteById(id);
    }

    //nie działa ale nic lepszego nie przyszło mi do głowy
    @RequestMapping("firm/byInitials/{initials}")
    @ResponseBody
    public List<Employee> findByInitials(@PathVariable("initials") String initials, Employee employee) {
        initials = employee.getFirstName().substring(0, 1) + employee.getLastName().substring(0, 1);
        return rep.findByInitials(initials);
    }
}
