package firm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Transactional
    @Modifying
    @Query("UPDATE Employee e SET e.salaryGr = e.salaryGr + ?2 WHERE e.id = ?1")
    void salaryRaise(Long id, long raise);
    List<Employee> findBySalaryGr(Long salaryGr);
    List<Employee> findBySalaryGrGreaterThan(Long salaryGr);
    List<Employee> findByLastName(String lastName);
    List<Employee> findByOrderByLastName();
    @Query("SELECT e FROM Employee e WHERE e.firstName LIKE 'SUBSTRING(?1, 0, 1)%' AND e.lastName LIKE 'SUBSTRING(?1, 1)%'")
    List<Employee> findByInitials(String initials);
}
